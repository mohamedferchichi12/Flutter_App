package com.example.appbank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
