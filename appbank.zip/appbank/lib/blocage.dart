import 'package:appbank/opposition.dart';
import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'comptes.dart';
import 'loginscreen.dart';

class Blocage extends StatefulWidget {
  const Blocage({super.key});

  @override
  State<Blocage> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
body:
Container(
  // frame2EMw (1:8169)
  width:  double.infinity,
  height:  522*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroupzzkbKuB (NYT2KBhXbbrxWVc3xNzzKb)
  left:  0*fem,
  top:  182*fem,
  child:  
Container(
  width:  313*fem,
  height:  51*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogrouprjlheAm (NYT2TbdBFwzuSC5WCLRJLH)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
  width:  128*fem,
  height:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xff0f1657),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Center(
  child:  
Text(
  'Plafond',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
Container(
  // autogroupetu5UQh (NYT2XbWWsyXfv1TAWTETU5)
  width:  128*fem,
  height:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xff060f63),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Center(
  child:  
Text(
  'Blocage',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
  ],
),
),
),
Positioned(
  // autogroupwyhkaid (NYT2f1Tq8pHRikahfswyhK)
  left:  97*fem,
  top:  266*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(13*fem, 30*fem, 12*fem, 8*fem),
  width:  113*fem,
  height:  86*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        ""
      ),
    ),
  ),
  child:  
Align(
  // cartedbloquebloquersxd (1:8175)
  alignment:  Alignment.bottomCenter,
  child:  
SizedBox(
  child:  
Container(
  constraints:  BoxConstraints (
    maxWidth:  88*fem,
  ),
  child:  
Text(
  'Carte débloquée\nBloquer ?',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
),
),
Positioned(
  // autogroupcjjbAwj (NYT2mkmb7z7inC9dSxCJjb)
  left:  10*fem,
  top:  411*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  319*fem,
  height:  66.95*fem,
  child:  
Image.network(
  "https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-18-256.png",
  width:  319*fem,
  height:  66.95*fem,
),
),
),
),
Positioned(
  // autogroupb2qh4XK (NYT2uRDVECiXNB7eP1b2Qh)
  left:  10*fem,
  top:  479*fem,
  child:  
Container(
  width:  279*fem,
  height:  19*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // mescomptesCNd (1:8178)
  margin:  EdgeInsets.fromLTRB(0*fem, 3*fem, 134*fem, 0*fem),
  child:  
Text(
  'Mes comptes\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x5e000000),
  ),
),
),
Container(
  // depenses7Vb (1:8177)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
  child:  
Text(
  'Depenses',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x49000000),
  ),
),
),
  ],
),
),
),
Positioned(
  // autogrouppgupdTw (NYT2B76f56BjxSuuQbpGuP)
  left:  0*fem,
  top:  13*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(80*fem, 9*fem, 78*fem, 9*fem),
  width:  313*fem,
  height:  71*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
       ""
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Text(
  'Plafond & Blocage\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  18*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
Positioned(
  // lockeP3 (1:8184)
  left:  139*fem,
  top:  270*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  37*fem,
  height:  22*fem,
  child:  
Image.network(
  "https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-68-256.png",
  width:  37*fem,
  height:  22*fem,
),
),
),
),
Positioned(
  // lockfillvrM (1:8195)
  left:  195*fem,
  top:  195*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  25*fem,
  height:  25*fem,
  child:  
Image.network(
  "https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-68-256.png",
  width:  25*fem,
  height:  25*fem,
),
),
),
),
Positioned(
  // cashcoinRYD (1:8198)
  left:  240*fem,
  top:  443*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  37*fem,
  height:  37*fem,
  child:  
Image.network(
  "https://cdn0.iconfinder.com/data/icons/shopping-196/48/bl_846_bank_machine_atm_bankomat_cashpoint_withdraw_money-256.png",
  width:  37*fem,
  height:  37*fem,
),
),
),
),
Positioned(
  // databaseaddwWZ (1:8200)
  left:  8*fem,
  top:  195*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  25*fem,
  height:  25*fem,
  child:  
Image.network(
  "https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-77-512.png",
  width:  25*fem,
  height:  25*fem,
),
),
),
),
Positioned(
  // menubuttonevm (1:8207)
  left:  12*fem,
  top:  20*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
 "https://cdn4.iconfinder.com/data/icons/wirecons-free-vector-icons/32/menu-alt-256.png",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
  ],
),
));}