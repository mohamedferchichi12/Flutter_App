import 'package:awesome_snackbar_content/awesome_snackbar_content.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'forgetPassword.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:appbank/loginscreen.dart';

class loginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<loginScreen> {
  bool _obscureText = true;

  final _emailController = TextEditingController();
  final _passWordController = TextEditingController();
  Future<void> signIn(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passWordController.text.trim(),
      );
      Navigator.of(context).pushNamed('/');
    } catch (e) {
      final materialBanner = MaterialBanner(
        /// need to set following properties for best effect of awesome_snackbar_content
        elevation: 0,
        backgroundColor: Color(0xff181f29),
        forceActionsBelow: true,
        content: AwesomeSnackbarContent(
          title: 'Oh Hey!!',
          message:
              'Sorry you can not Sign in 🙁 cause you make an invalid account if you forget your password you can reset him',

          /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
          contentType: ContentType.failure,
          // to configure for material banner
          inMaterialBanner: true,
        ),
        actions: const [SizedBox.shrink()],
      );

      ScaffoldMessenger.of(context)
        ..hideCurrentMaterialBanner()
        ..showMaterialBanner(materialBanner);
    }
  }

// Call the signIn function
  SignIn(BuildContext context) {
    signIn(context);
  }

  goToSignUp() {
    Navigator.of(context).pushReplacementNamed('SignupScreen');
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passWordController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          return Future.value(false);
        },
        child: Scaffold(
          backgroundColor: Color(0xff181f29),
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Image
                    Image.asset(
                      'assets/images/slogan.png',
                      //change image size*
                      width: 280,
                      height: 240,
                    ),
                    // Title
                    // Text(
                    //   'Sign IN',
                    //   style: GoogleFonts.robotoCondensed(
                    //     fontSize: 40,
                    //     color: Color(0xFF42c95e),
                    //     fontWeight: FontWeight.bold,
                    //   ),
                    // ),

                    // Subtitle
                    Text(
                      'Welcome to Solares',
                      style: GoogleFonts.robotoCondensed(
                        fontSize: 18,
                        color: Color.fromRGBO(220, 220, 220, 1),
                      ),
                    ),
                    //make some distance between them
                    SizedBox(
                      height: 20,
                    ),
                    // Email Textfield
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Color(0xFFDCDCDC),
                            borderRadius: BorderRadius.circular(12)),
                        child: TextField(
                          controller: _emailController,
                          decoration: InputDecoration(
                            hintText: 'Email'
                            //text position
                            ,
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 20),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    // Passwor Textfield
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25),
                      child: Container(
                        decoration: BoxDecoration(
                            color: Color(0xFFDCDCDC),
                            borderRadius: BorderRadius.circular(12)),
                        child: TextField(
                          obscureText: _obscureText,
                          controller: _passWordController,
                          decoration: InputDecoration(
                            hintText: 'Password',
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 20),
                            border: InputBorder.none,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscureText
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  _obscureText = !_obscureText;
                                });
                              },
                            ),
                            // contentPadding: EdgeInsets.symmetric(horizontal: 20),
                            // border: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    // sign in button
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 25),
                      child: GestureDetector(
                        // onTap: SignIn,
                        child: Container(
                            padding: EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Color(0xff181f29),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Container(
                              width: 350,
                              height: 60,
                              child: Center(
                                child: ElevatedButton(
                                  onPressed: () => SignIn(context),
                                  style: ElevatedButton.styleFrom(
                                    minimumSize: Size(350, 80),
                                    primary: Color(
                                        0xFF42c95e), // Change the button color here
                                  ),
                                  child: Text(
                                    'Sign In',
                                    style: GoogleFonts.robotoCondensed(
                                      fontSize: 20,
                                      color: Color(0xFFFFFFFF),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            )),
                      ),
                    ),
                    // Text: sign up
                    SizedBox(
                      height: 10,
                    ),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      GestureDetector(
                          child: Text(
                            'Forgot Paspword?',
                            style: GoogleFonts.robotoCondensed(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF42c95e),
                              // fontSize: 19,
                            ),
                          ),
                          onTap: () =>
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => forgetPass(),
                              ))),
                      // GestureDetector
                      SizedBox(height: 16),
                    ]),
                    SizedBox(
                      height: 30,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Don\'t have an account?',
                          style: GoogleFonts.robotoCondensed(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(5),
                        ),
                        GestureDetector(
                          onTap: goToSignUp,
                          child: Text(
                            'Sign Up',
                            style: GoogleFonts.robotoCondensed(
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF42c95e),
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ),
        ));
  }
}