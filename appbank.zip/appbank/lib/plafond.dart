import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'cartes.dart';
import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => createState();
}

@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
      appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body:

Container(
  // androidsmall678d (1:8041)
  width:  double.infinity,
  height:  580*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroup5ecq1E1 (VYjSzMVWosNvYcDsAA5ECq)
  left:  0*fem,
  top:  0*fem,
  child:  
Container(
  width:  336*fem,
  height:  436*fem,
  child:  
Stack(
  children:  [
Positioned(
  // autogroupzc5oVus (VYjRkZDpCK4V6jPdP8ZC5o)
  left:  0*fem,
  top:  4*fem,
  child:  
Container(
  width:  313*fem,
  height:  86*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        "",
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Center(
  child:  
Text(
  'Plafond & Blocage',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
Positioned(
  // menubuttongDf (1:8043)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
  "",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
Positioned(
  // autogroupneivBAR (VYjRyoLkKGt2SNh1AeNeiV)
  left:  8*fem,
  top:  134*fem,
  child:  
Container(
  width:  269*fem,
  height:  31*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupawxvVwo (VYjS9TjKEWFDGGLrFmAwxV)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 33*fem, 0*fem),
  width:  118*fem,
  height:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xff0f1657),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Center(
  child:  
Text(
  'Plafond',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
Container(
  // autogroupkwvoaTT (VYjSD8HsihKFNRwCshkWVo)
  padding:  EdgeInsets.fromLTRB(5.51*fem, 0.7*fem, 30*fem, 0.7*fem),
  height:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xff0f1657),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // v2J8Z (1:8072)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 12.91*fem, 4.48*fem),
  width:  15.58*fem,
  height:  25.13*fem,
  child:  
Image.network(
  "",
  width:  15.58*fem,
  height:  25.13*fem,
),
),
Container(
  // blocagezn5 (1:8056)
  margin:  EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
  child:  
Text(
  'Blocage',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
  ],
),
),
  ],
),
),
),
Positioned(
  // autogroupkwb7KZT (VYjSUsLeMRbGWTbNMYKwb7)
  left:  14*fem,
  top:  278*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(12*fem, 14*fem, 61*fem, 14*fem),
  width:  308*fem,
  height:  100*fem,
  decoration:  BoxDecoration (
    color:  Color(0xfff5f5f5),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // c2m (1:8088)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 196*fem, 0*fem),
  child:  
Text(
  '0',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  16*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffa5c4f1),
  ),
),
),
Text(
  // vp9 (1:8089)
  '100',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  16*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffa5c4f1),
  ),
),
  ],
),
),
),
Positioned(
  // toggleoffH8u (1:8059)
  left:  127*fem,
  top:  292*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  32*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  32*fem,
  height:  16*fem,
),
),
),
),
Positioned(
  // line1y1j (1:8061)
  left:  7*fem,
  top:  275*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  313*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // plafondgab1000tndVEy (1:8062)
  left:  65*fem,
  top:  227*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  135*fem,
  height:  15*fem,
  child:  
RichText(
  text:  
TextSpan(
  style:  TextStyle(
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff070b34),
  ),
  children:  [
TextSpan(
  text:  'Plafond GAB',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff07116c),
  ),
),
TextSpan(
  text:  ' ',
),
TextSpan(
  text:  ' 1000TND',
  style: TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffff0808),
  ),
),
  ],
),
),
),
),
),
Positioned(
  // button1G2m (1:8063)
  left:  61*fem,
  top:  387.5*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(61*fem, 0*fem, 64*fem, 0*fem),
  width:  196*fem,
  height:  26.5*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff0f1657)],
      stops:  <double>[0.151],
    ),
  ),
  child:  
Text(
  'Valider',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  20*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
),
Positioned(
  // autogroupr1xmt49 (VYjSMni7ERJF5NF8tHr1xM)
  left:  53*fem,
  top:  187*fem,
  child:  
Container(
  width:  159*fem,
  height:  15*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // gabR45 (1:8065)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 111*fem, 0*fem),
  child:  
Text(
  'GAB',
  style: TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Text(
  // tpeYeV (1:8066)
  'TPE',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
),
Positioned(
  // toggleontyF (1:8067)
  left:  119*fem,
  top:  185*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  20*fem,
  child:  
Image.network(
  "",
  width:  34*fem,
  height:  20*fem,
),
),
),
),
Positioned(
  // databaseadd12H (1:8073)
  left:  18*fem,
  top:  136*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  25*fem,
  height:  25*fem,
  child:  
Image.network(
  "",
  width:  25*fem,
  height:  25*fem,
),
),
),
),
  ],
),
),
),
Positioned(
  // autogroupqtztv9F (VYjSchSw2ZRSHGT38gqTZT)
  left:  0*fem,
  top:  436*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  337*fem,
  height:  54.54*fem,
  child:  
Image.network(
  "",
  width:  337*fem,
  height:  54.54*fem,
),
),
),
),
Positioned(
  // cashcoincXs (1:8084)
  left:  268*fem,
  top:  459*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  37*fem,
  height:  37*fem,
  child:  
Image.network(
  "",
  width:  37*fem,
  height:  37*fem,
),
),
),
),
Positioned(
  // autogroupungrXuj (VYjSkcPQz9sHeVFXqNuNgR)
  left:  1.5*fem,
  top:  492*fem,
  child:  
Container(
  width:  321.5*fem,
  height:  16*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // mescomptes4em (1:8086)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 176.5*fem, 0*fem),
  child:  
Text(
  'Mes comptes\n',
  textAlign:  TextAlign.center,
  style: TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x5e000000),
  ),
),
),
Text(
  // depensesymj (1:8087)
  'Depenses',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x49000000),
  ),
),
  ],
),
),
),
  ],
),
));}