import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';
import 'package:firebase_auth/firebase_auth.dart';

class parametres extends StatefulWidget {
  const parametres({super.key});

  @override
  State<parametres> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
   appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
body:
Container(
  // androidsmall10eZX (1:8409)
  width:  double.infinity,
  height:  640*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroupunqo8zV (NYTA7iCWLiLm3WK8ZYuNqo)
  left:  0*fem,
  top:  37*fem,
  child:  
Container(
  width:  360*fem,
  height:  603*fem,
  child:  
Stack(
  children:  [
Positioned(
  // persondwF (1:8410)
  left:  174*fem,
  top:  277*fem,
  child:  
Container(
  width:  12*fem,
  height:  12*fem,
),
),
Positioned(
  // autogroupbh5tM6Z (NYT9c9DSbowRQwjoqPbh5T)
  left:  36*fem,
  top:  182*fem,
  child:  
Container(
  width:  188*fem,
  height:  28*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // subtractr3K (1:8411)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 7*fem),
  width:  24*fem,
  height:  21*fem,
  child:  
Image.network(
  "https://cdn2.iconfinder.com/data/icons/web-line-2/32/user-256.png",
  width:  24*fem,
  height:  21*fem,
),
),
Text(
  // informationspersonelleskeV (1:8432)
  'Informations personelles',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff69aded),
  ),
),
  ],
),
),
),
Positioned(
  // line1Too (1:8412)
  left:  11*fem,
  top:  216*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  338*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x84706969),
  ),
),
),
),
),
Positioned(
  // line2atR (1:8413)
  left:  11*fem,
  top:  277*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  338*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x84706969),
  ),
),
),
),
),
Positioned(
  // arrowrightcircleJJd (1:8414)
  left:  333*fem,
  top:  187*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  24*fem,
  height:  21*fem,
  child:  
Image.network(
 "  // arrowrightcircleJJd (1:8414)",
  width:  24*fem,
  height:  21*fem,
),
),
),
),
Positioned(
  // autogroup7d3oNZP (NYT9jyKjGwmbBkbUcY7D3o)
  left:  81*fem,
  top:  247*fem,
  child:  
Container(
  width:  276*fem,
  height:  23*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // modifiermotdepassei7T (1:8433)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 125*fem, 0*fem),
  child:  
Text(
  'Modifier mot de passe',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff69aded),
  ),
),
),
Container(
  // arrowrightcircleR1s (1:8418)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
  width:  24*fem,
  height:  21*fem,
  child:  
Image.network(
 "https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-ios7-arrow-right-64.png",
  width:  24*fem,
  height:  21*fem,
),
),
  ],
),
),
),
Positioned(
  // lockuhj (1:8419)
  left:  39*fem,
  top:  233*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  24*fem,
  height:  3521*fem,
  child:  
Image.network(
  "",
  width:  24*fem,
  height:  3521*fem,
),
),
),
),
Positioned(
  // lockfillPcu (1:8429)
  left:  36*fem,
  top:  247*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  24*fem,
  height:  21*fem,
  child:  
Image.network(
  "https://cdn4.iconfinder.com/data/icons/multimedia-75/512/multimedia-40-64.png",
  width:  24*fem,
  height:  21*fem,
),
),
),
),
Positioned(
  // autogroupqimfuLM (NYT9tDazNNgAvdBH1QQimF)
  left:  11*fem,
  top:  542*fem,
  child:  
Container(
  width:  341*fem,
  height:  61*fem,
  child:  
Stack(
  children:  [
Positioned(
  // line53Bf (1:8445)
  left:  0*fem,
  top:  22*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  337*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x84797070),
  ),
),
),
),
),
Positioned(
  // ellipse6x3j (1:8446)
  left:  135*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  66*fem,
  height:  47*fem,
  child:  
Image.network(
  "",
  width:  66*fem,
  height:  47*fem,
),
),
),
),
Positioned(
  // vectorfiq (1:8447)
  left:  156*fem,
  top:  11*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  26*fem,
  height:  23*fem,
  child:  
Image.network(
  "",
  width:  26*fem,
  height:  23*fem,
),
),
),
),
Positioned(
  // aproposQRX (1:8450)
  left:  286*fem,
  top:  46*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  55*fem,
  height:  15*fem,
  child:  
Text(
  'A propos',
  style: TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0x93000000),
  ),
),
),
),
),
  ],
),
),
),
Positioned(
  // infocircleGTj (1:8448)
  left:  309*fem,
  top:  573*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
),
),
  ],
),
),
),
Positioned(
  // autogroup2zrwzuX (NYT9Sp9epR2xxhsGST2zRw)
  left:  0*fem,
  top:  0*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(97*fem, 5*fem, 108*fem, 34*fem),
  width:  360*fem,
  height:  86*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
       ""
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // paramtresE3B (1:8451)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 17*fem),
  child:  
Text(
  'Paramétres',
  style: TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
Text(
  // modifiezvosparamtresxE5 (1:8452)
  'Modifiez vos paramètres :',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
  ],
),
),
),
Positioned(
  // menubuttonu9K (1:8435)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
 "",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
  ],
),
));}