import 'package:appbank/blocage.dart';
import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';

class cartes extends StatefulWidget {
  const cartes({super.key});

  @override
  State<cartes> createState() => createState();
}

@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
      appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      backgroundColor: Color.fromARGB(255, 249, 248, 247),
      body: SafeArea(
          child: Center(
              child: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          height: 566 * fem,
          decoration: BoxDecoration(
            color: Color(0xffffffff),
          ),
          child: Stack(
            children: [
              Positioned(
                left: 0 * fem,
                top: 0 * fem,
                child: Container(
                  width: 354 * fem,
                  height: 92 * fem,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage('https://www.panofrance.fr/asset/98/38/AST229838-XL.jpg'),
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(20 * fem),
                      topRight: Radius.circular(20 * fem),
                      bottomRight: Radius.circular(40 * fem),
                      bottomLeft: Radius.circular(40 * fem),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'Mes cartes',
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                        fontSize: 16 * fem,
                        fontWeight: FontWeight.w500,
                        height: 1.2175 * fem / fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 14 * fem,
                top: 8 * fem,
                child: Align(
                  child: SizedBox(
                    width: 34 * fem,
                    height: 29 * fem,
                    child: Image.network(
                      'https://cdn4.iconfinder.com/data/icons/wirecons-free-vector-icons/32/menu-alt-256.png',
                      width: 34 * fem,
                      height: 29 * fem,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 0 * fem,
                top: 37 * fem,
                child: Container(
                  width: 354 * fem,
                  height: 529 * fem,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 14 * fem,
                        top: 83 * fem,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(
                              3.5 * fem, 9.5 * fem, 3.5 * fem, 11.5 * fem),
                          width: 175 * fem,
                          height: 37 * fem,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30 * fem),
                            gradient: LinearGradient(
                              begin: Alignment(-1, 0),
                              end: Alignment(1, 0),
                              colors: <Color>[Color(0xff221f92)],
                              stops: <double>[0.151],
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 32 * fem, 0 * fem),
                                child: Text(
                                  '       Assurance voyage',
                                  style: TextStyle(
                                    fontFamily: 'Montserrat',
                                    fontSize: 12 * fem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.2175 * fem / fem,
                                    color: Color(0xfffdf5f5),
                                  ),
                                ),
                              ),
                              Container(
                                width: 26 * fem,
                                height: 16 * fem,
                                child: Image.network(
                                  'https://cdn0.iconfinder.com/data/icons/summer-holidays-19/32/Summer_Holidays_holidays_vacation_travel_plane_fly_airplane-256.png',
                                  width: 26 * fem,
                                  height: 16 * fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 14 * fem,
                        top: 151.5 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 184 * fem,
                            height: 18 * fem,
                            child: Text(
                              'Plafonds & blocage cartes',
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontSize: 14 * fem,
                                fontWeight: FontWeight.w500,
                                height: 1.2175 * fem / fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0 * fem,
                        top: 267 * fem,
                        child: Container(
                          width: 317 * fem,
                          height: 42.5 * fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 2.93 * fem, 0.5 * fem),
                                width: 58.07 * fem,
                                height: 42 * fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: 2 * fem,
                                      top: 3 * fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 52.07 * fem,
                                          height: 39 * fem,
                                          child: Image.network(
                                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpiu7_ZAFuhIjw6rfzEJWmQ2_NHpDD6N1LRmaECsfA9w&s',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: 0 * fem,
                                      top: 0 * fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 52 * fem,
                                          height: 39 * fem,
                                          child: Image.network(
                                            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpiu7_ZAFuhIjw6rfzEJWmQ2_NHpDD6N1LRmaECsfA9w&s',
                                            width: 52 * fem,
                                            height: 39 * fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 39 * fem, 1.5 * fem),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                        margin: EdgeInsets.fromLTRB(
                                            0 * fem, 0 * fem, 0 * fem, 9 * fem),
                                        child: TextButton(
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      Blocage()),
                                            );
                                          },
                                          child: Text('Press Me'),
                                        )),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 1 * fem, 0 * fem),
                                      child: Text(
                                        'Montant autorisé',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 8 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 27 * fem, 0 * fem),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 4.5 * fem),
                                      child: Text(
                                        '4000.000TND',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 12 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          7 * fem, 0 * fem, 0 * fem, 0 * fem),
                                      child: Text(
                                        '4000TND',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 10 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 0 * fem, 7.5 * fem),
                                width: 28 * fem,
                                height: 24 * fem,
                                child: Image.network(
                                  'https://cdn4.iconfinder.com/data/icons/basic-user-interface-elements/700/edit-change-pencil-256.png',
                                  width: 28 * fem,
                                  height: 24 * fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 5 * fem,
                        top: 190 * fem,
                        child: Container(
                          width: 253 * fem,
                          height: 56.5 * fem,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 0 * fem, 11 * fem, 11.5 * fem),
                                width: 39 * fem,
                                height: 45 * fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: 0 * fem,
                                      top: 6 * fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 39 * fem,
                                          height: 39 * fem,
                                          child: Image.network(
                                            'https://cdn0.iconfinder.com/data/icons/finance-and-banking-20/64/finance_distributer_money_cash_payment_dollar_ATM-256.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: 4 * fem,
                                      top: 0 * fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 35 * fem,
                                          height: 44 * fem,
                                          child: Image.network(
                                            'https://cdn4.iconfinder.com/data/icons/basic-user-interface-elements/700/edit-change-pencil-256.png',
                                            width: 35 * fem,
                                            height: 44 * fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(
                                    0 * fem, 13 * fem, 42 * fem, 4.5 * fem),
                                height: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 0 * fem, 14 * fem),
                                      child: Text(
                                        'Plafond GAB:',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 12 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          0 * fem, 0 * fem, 1 * fem, 0 * fem),
                                      child: Text(
                                        'Montant autorisé',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 8 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0 * fem,
                                          0 * fem, 0 * fem, 15.5 * fem),
                                      child: Text(
                                        '1950.000TND',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 12 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(
                                          4 * fem, 0 * fem, 0 * fem, 0 * fem),
                                      child: Text(
                                        '1950TND',
                                        style: TextStyle(
                                          fontFamily: 'Montserrat',
                                          fontSize: 10 * fem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2175 * fem / fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 2 * fem,
                        top: 265 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 320 * fem,
                            height: 1 * fem,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 5 * fem,
                        top: 329.5 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 163 * fem,
                            height: 18 * fem,
                            child: Text(
                              'Dernières Transactions',
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontSize: 14 * fem,
                                fontWeight: FontWeight.w500,
                                height: 1.2175 * fem / fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 283 * fem,
                        top: 212 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 16 * fem,
                            height: 16 * fem,
                            child: Image.network(
                              '',
                              width: 16 * fem,
                              height: 16 * fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 16 * fem,
                        top: 368 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 16 * fem,
                            height: 16 * fem,
                            child: Image.network(
                              'https://cdn1.iconfinder.com/data/icons/freeline/32/home_house_real_estate-256.png',
                              width: 16 * fem,
                              height: 16 * fem,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 14 * fem,
                        top: 363 * fem,
                        child: Container(
                          width: 338 * fem,
                          height: 119 * fem,
                          child: Stack(
                            children: [
                              Positioned(
                                left: 28 * fem,
                                top: 0 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 69 * fem,
                                    height: 15 * fem,
                                    child: Text(
                                      'Retrait Gab',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 12 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 28 * fem,
                                top: 20 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 163 * fem,
                                    height: 20 * fem,
                                    child: Text(
                                      'Ste AGENCE ENNASR>AV HEDI NOUIRA\n17-07-2023 19.00\n',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 8 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 4.5 * fem,
                                top: 73 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 15 * fem,
                                    height: 14 * fem,
                                    child: Image.network(
                                      'https://cdn1.iconfinder.com/data/icons/freeline/32/home_house_real_estate-256.png',
                                      width: 15 * fem,
                                      height: 14 * fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 30 * fem,
                                top: 67 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 69 * fem,
                                    height: 15 * fem,
                                    child: Text(
                                      'Retrait Gab',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 12 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 30 * fem,
                                top: 87 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 163 * fem,
                                    height: 20 * fem,
                                    child: Text(
                                      'Ste AGENCE BIZERTE>AV HEDI NOUIRA\n13-07-2023 19.00\n',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 8 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 259 * fem,
                                top: 2 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 49 * fem,
                                    height: 10 * fem,
                                    child: Text(
                                      '100.000TND',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 8 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xffec0f0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 263 * fem,
                                top: 71 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 49 * fem,
                                    height: 10 * fem,
                                    child: Text(
                                      '100.000TND',
                                      style: TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 8 * fem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.2175 * fem / fem,
                                        color: Color(0xffec0f0f),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 0 * fem,
                                top: 0 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 338 * fem,
                                    height: 119 * fem,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0x16a09898),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 277 * fem,
                                top: 90 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 16 * fem,
                                    height: 16 * fem,
                                    child: Image.network(
                                      'https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-77-256.png',
                                      width: 16 * fem,
                                      height: 16 * fem,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 269 * fem,
                                top: 21 * fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 26 * fem,
                                    height: 25 * fem,
                                    child: Image.network(
                                      'https://img.freepik.com/vecteurs-libre/vecteur-forme-geometrique-ronde-course_53876-175080.jpg',
                                      width: 26 * fem,
                                      height: 25 * fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 289 * fem,
                        top: 388 * fem,
                        child: Align(
                          child: SizedBox(
                            width: 16 * fem,
                            height: 16 * fem,
                            child: Image.network(
                              'https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-77-256.png',
                              width: 16 * fem,
                              height: 16 * fem,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ))));
}
