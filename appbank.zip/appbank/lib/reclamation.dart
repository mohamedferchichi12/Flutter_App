import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';


class reclamation extends StatefulWidget {
  const reclamation({super.key});

  @override
  State<reclamation> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
     appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body: 
Container(
  // androidsmall1cYw (1:2)
  width:  double.infinity,
  height:  640*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroupa8cfG7h (SUdR3XsufJAEzpgfD7A8cf)
  left:  0*fem,
  top:  231*fem,
  child:  
Container(
  width:  360*fem,
  height:  409*fem,
  child:  
Stack(
  children:  [
Positioned(
  // line1iEb (1:3)
  left:  17*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  316*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff0c15e2),
  ),
),
),
),
),
Positioned(
  // line2951 (1:4)
  left:  17*fem,
  top:  197*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  316*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff0c15e2),
  ),
),
),
),
),
Positioned(
  // line3qiX (1:5)
  left:  17*fem,
  top:  142*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  316*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff0c15e2),
  ),
),
),
),
),
Positioned(
  // line4JMD (1:6)
  left:  17*fem,
  top:  89*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  316*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff0c15e2),
  ),
),
),
),
),
Positioned(
  // emailDUB (1:8)
  left:  17*fem,
  top:  62*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  36*fem,
  height:  15*fem,
  child:  
Text(
  'E-mail',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff605959),
  ),
),
),
),
),
Positioned(
  // objetdno (1:9)
  left:  17*fem,
  top:  118*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  31*fem,
  height:  15*fem,
  child:  
Text(
  'Objet',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff605959),
  ),
),
),
),
),
Positioned(
  // contenu7CB (1:10)
  left:  17*fem,
  top:  176*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  49*fem,
  height:  15*fem,
  child:  
Text(
  'Contenu',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff605959),
  ),
),
),
),
),
Positioned(
  // button1MsD (1:15)
  left:  8*fem,
  top:  231*fem,
  child:  
Container(
  width:  322*fem,
  height:  50*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff0f1657)],
      stops:  <double>[0.151],
    ),
  ),
  child:  
Center(
  child:  
Text(
  'Envoyer une réclamation',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
),
),
Positioned(
  // autogroupu58bibH (SUdQpNbApnxPFbL7M8u58b)
  left:  11*fem,
  top:  348*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  337*fem,
  height:  47*fem,
  child:  
Image.network(
  "",
  width:  337*fem,
  height:  47*fem,
),
),
),
),
Positioned(
  // infocircleM8T (1:19)
  left:  309*fem,
  top:  379*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
),
),
Positioned(
  // aproposq3d (1:22)
  left:  291*fem,
  top:  396*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  55*fem,
  height:  15*fem,
  child:  
Text(
  'A propos',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0x93000000),
  ),
),
),
),
),
  ],
),
),
),
Positioned(
  // typeV8B (1:7)
  left:  152*fem,
  top:  211*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  24*fem,
  height:  13*fem,
  child:  
Text(
  'Type',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x8c5f5858),
  ),
),
),
),
),
Positioned(
  // chevronexpandyp3 (1:11)
  left:  317*fem,
  top:  215*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
),
),
Positioned(
  // autogroupnpmzrcw (SUdQcxkWwvfry2pusbNPmZ)
  left:  0*fem,
  top:  0*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(95*fem, 7*fem, 94*fem, 7*fem),
  width:  360*fem,
  height:  86*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        ""
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Text(
  'Détaillez votre réclamation :',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
Positioned(
  // menubuttonZ9y (1:33)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
  "",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
  ],
),
));}