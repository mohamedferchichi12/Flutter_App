import 'dart:math';

import 'package:appbank/loginscreen.dart';
import 'package:appbank/opposition.dart';
import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'comptes.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body: 
Container(
  // androidsmall3ZTV (1:227)
  width:  double.infinity,
  height:  426*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // menubuttondy9 (1:229)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
  "",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
Positioned(
  // autogroupzgajvST (PbuCNYYCWffWEMNEkRzGAj)
  left:  122*fem,
  top:  13*fem,
  child:  
Container(
  width:  96*fem,
  height:  22*fem,
  child:  
Stack(
  children:  [
Positioned(
  // dpensesr5D (1:239)
  left:  20*fem,
  top:  2*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  76*fem,
  height:  20*fem,
  child:  
Text(
  'Dépenses',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  16*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
Positioned(
  // dpensesU6b (1:291)
  left:  0*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  58*fem,
  height:  15*fem,
  child:  
Text(
  'Dépenses',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
  ),
),
),
),
),
  ],
),
),
),
Positioned(
  // filtrea9d (1:241)
  left:  6*fem,
  top:  90*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  38*fem,
  height:  20*fem,
  child:  
Text(
  'Filtre',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  16*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // autogroupp9kk5cB (PbuCYxQWz2ZqPxXX9Sp9kK)
  left:  7*fem,
  top:  118*fem,
  child:  
Container(
  width:  211*fem,
  height:  15*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // datedebutzz3 (1:242)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 85*fem, 0*fem),
  child:  
Text(
  'Date Debut :',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Text(
  // datefinif9 (1:243)
  'Date Fin :',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
),
Positioned(
  // autogroupkqd9fqH (PbuCjXwE2JhXkPaTPYkqd9)
  left:  7*fem,
  top:  141*fem,
  child:  
Container(
  width:  237*fem,
  height:  24*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // autogroup98mmoAo (PbuCv2djn8DYWQgZi798MM)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 57*fem, 0*fem),
  width:  90*fem,
  height:  19*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffd9d9d9),
    borderRadius:  BorderRadius.circular(5*fem),
  ),
  child:  
Center(
  child:  
Text(
  '--/--/----',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
Container(
  // autogroup55np2JT (PbuCzCBTy4ygB3wssK55nP)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
  width:  90*fem,
  height:  20*fem,
  child:  
Stack(
  children:  [
Positioned(
  // rectangle2MLj (1:245)
  left:  0*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  90*fem,
  height:  19*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(5*fem),
    color:  Color(0xffd9d9d9),
  ),
),
),
),
),
Positioned(
  // SNB (1:246)
  left:  4*fem,
  top:  5*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  53*fem,
  height:  15*fem,
  child:  
Text(
  '--/--/----',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
  ],
),
),
  ],
),
),
),
Positioned(
  // calendardateXeX (1:247)
  left:  76*fem,
  top:  149*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16.4*fem,
  height:  11.97*fem,
  child:  
Image.network(
  "",
  width:  16.4*fem,
  height:  11.97*fem,
),
),
),
),
Positioned(
  // calendardate375 (1:249)
  left:  187.9485168457*fem,
  top:  129.8455047607*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  13.82*fem,
  height:  10.65*fem,
  child:  
Image.network(
 "",
  width:  13.82*fem,
  height:  10.65*fem,
),
),
),
),
Positioned(
  // autogroupy1vwMdZ (PbuD6SW4FV7sg1qr77y1vw)
  left:  11*fem,
  top:  174*fem,
  child:  
Container(
  width:  206*fem,
  height:  15*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // cartesrqD (1:252)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 109*fem, 0*fem),
  child:  
Text(
  'Cartes:',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Text(
  // comptesM1H (1:253)
  'Comptes:',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
),
Positioned(
  // autogrouppkwd6jZ (PbuDErRhuqFpbiKJM5PKwd)
  left:  0*fem,
  top:  197*fem,
  child:  
Container(
  width:  251*fem,
  height:  19*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // rectangle3qSF (1:254)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 71*fem, 0*fem),
  width:  90*fem,
  height:  19*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(10*fem),
    color:  Color(0xffc6d0f3),
  ),
),
Container(
  // autogroup1eddmao (PbuDNrCP9tKMZM4cyK1eDD)
  padding:  EdgeInsets.fromLTRB(73.2*fem, 7*fem, 5.2*fem, 4.52*fem),
  height:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xffc7d1f4),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Align(
  // caretdowngxf (1:292)
  alignment:  Alignment.centerRight,
  child:  
SizedBox(
  width:  11.6*fem,
  height:  7.48*fem,
  child:  
Image.network(
  "",
  width:  11.6*fem,
  height:  7.48*fem,
),
),
),
),
  ],
),
),
),
Positioned(
  // caretdownQtf (1:256)
  left:  71*fem,
  top:  200*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
),
),
Positioned(
  // autogroupjttfXTV (PbuDcg8gG4Sg3synDdjttF)
  left:  10*fem,
  top:  321*fem,
  child:  
Container(
  width:  281*fem,
  height:  49*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupqxt7f3u (PbuDq17UFyVhryt4rAQxt7)
  margin:  EdgeInsets.fromLTRB(0*fem, 9*fem, 6*fem, 3*fem),
  width:  86*fem,
  height:  double.infinity,
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // autogrouphkcs9zf (PbuDufeN9fww66pLYdhKCs)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // rectangle5FXu (1:269)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 3*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xfff3c44d),
  ),
),
Text(
  // loisirsBAf (1:278)
  'Loisirs',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
Container(
  // rectangle11vP9 (1:275)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xfffde980),
  ),
),
  ],
),
),
Container(
  // autogroup7ddz3yZ (PbuE45a1p25t1oHnnb7dDZ)
  width:  189*fem,
  height:  double.infinity,
  child:  
Stack(
  children:  [
Positioned(
  // ffiltreriltrerQ3R (1:260)
  left:  33*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  125*fem,
  height:  18*fem,
  child:  
Text(
  'FFILTRERILTRER',
  style:  TextStyle (
    fontFamily: 'Public Sans',
    fontSize:  15*fem,
    fontWeight:  FontWeight.w500,
    height:  1.175*fem/fem,
    letterSpacing:  0.4300000072*fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
Positioned(
  // frame15vF (1:261)
  left:  0*fem,
  top:  11*fem,
  child:  
Container(
  width:  88*fem,
  height:  36*fem,
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // autogroupk55zDFm (PbuEJa9sBs8fFdmZRGK55Z)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // rectangle13kFh (1:277)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 1*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xff7a7676),
  ),
),
Text(
  // etuderJj (1:279)
  'Etude',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
Container(
  // autogroupmprwB67 (PbuERjcbbL3NH94cp4MPrw)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // alimuno (1:281)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 0*fem),
  child:  
Text(
  'Alim',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // rectangle10Eq5 (1:274)
  margin:  EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xfffd4d57),
  ),
),
  ],
),
),
  ],
),
),
),
Positioned(
  // rectangle12y1y (1:276)
  left:  94*fem,
  top:  13*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  51*fem,
  height:  10*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0xff210474),
  ),
),
),
),
),
Positioned(
  // voituregwy (1:280)
  left:  154*fem,
  top:  13*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  35*fem,
  height:  13*fem,
  child:  
Text(
  'Voiture',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // facturedomicileoWo (1:282)
  left:  83*fem,
  top:  36*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  81*fem,
  height:  13*fem,
  child:  
Text(
  'Facture Domicile',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
  ],
),
),
  ],
),
),
),
Positioned(
  // button1hMH (1:262)
  left:  33*fem,
  top:  229.5*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(61.5*fem, 0*fem, 67.5*fem, 0*fem),
  width:  213*fem,
  height:  25.5*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff0f1657)],
      stops:  <double>[0.151],
    ),
  ),
  child:  
Text(
  'FILTRER',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  20*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
),
Positioned(
  // dpensesparcatgoriegU7 (1:264)
  left:  10*fem,
  top:  274.5*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  147*fem,
  height:  15*fem,
  child:  
Text(
  'Dépenses par Catégorie',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // autogrouphzxyNrj (PbuDTWjH3amanTztfnHzXy)
  left:  184*fem,
  top:  301*fem,
  child:  
Container(
  width:  127*fem,
  height:  15*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // camembertJVV (1:265)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 30*fem, 0*fem),
  child:  
Text(
  'Camembert',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Text(
  // bardnf (1:266)
  'Bar',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
),
Positioned(
  // toggleoffC55 (1:267)
  left:  266*fem,
  top:  301*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
),
),
Positioned(
  // autogroupdmqhW5m (PbuF8dc7ve7YbrCK6DdMqh)
  left:  25*fem,
  top:  413*fem,
  child:  
Container(
  width:  225*fem,
  height:  14*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // rectangle7pMM (1:271)
  margin:  EdgeInsets.fromLTRB(0*fem, 2*fem, 8*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xff19093d),
  ),
),
Container(
  // grandesurfacekko (1:285)
  margin:  EdgeInsets.fromLTRB(0*fem, 1*fem, 3*fem, 0*fem),
  child:  
Text(
  'Grande Surface',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // rectangle6dpb (1:270)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffd9d9d9),
  ),
),
Container(
  // autresA3q (1:286)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
  child:  
Text(
  'Autres',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
  ],
),
),
),
Positioned(
  // autogroupf57v5Rh (PbuEx8ucApbXqq6CmfF57V)
  left:  4*fem,
  top:  380*fem,
  child:  
Container(
  width:  210*fem,
  height:  15*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // rectangle9Bjd (1:273)
  margin:  EdgeInsets.fromLTRB(0*fem, 1*fem, 6*fem, 0*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xff2ad527),
  ),
),
Container(
  // sant1Lb (1:283)
  margin:  EdgeInsets.fromLTRB(0*fem, 2*fem, 11*fem, 0*fem),
  child:  
Text(
  'Santé',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // rectangle8JqV (1:272)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 5*fem, 1*fem),
  width:  51*fem,
  height:  10*fem,
  decoration:  BoxDecoration (
    color:  Color(0xfff364b1),
  ),
),
Container(
  // habillementEj9 (1:284)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
  child:  
Text(
  'Habillement',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
  ],
),
),
),
  ],
),
));}