import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart'; // Importez le package

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Email Validator Example',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Email Validator Example'),
        ),
        body: EmailValidatorExample(),
      ),
    );
  }
}

class EmailValidatorExample extends StatefulWidget {
  @override
  _EmailValidatorExampleState createState() => _EmailValidatorExampleState();
}

class _EmailValidatorExampleState extends State<EmailValidatorExample> {
  String email = '';
  bool isEmailValid = true;

  void validateEmail(String input) {
    setState(() {
      email = input;
      isEmailValid = EmailValidator.validate(email); // Utilisez la méthode validate de EmailValidator
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        TextField(
          onChanged: (input) => validateEmail(input),
          decoration: InputDecoration(
            labelText: 'Email',
            hintText: 'Enter an email',
            errorText: isEmailValid ? null : 'Invalid email',
          ),
        ),
        SizedBox(height: 20),
        Text(
          'Email: $email',
          style: TextStyle(fontSize: 18),
        ),
      ],
    );
  }
}
