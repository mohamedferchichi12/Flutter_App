import 'package:appbank/parametres.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';
import 'package:firebase_auth/firebase_auth.dart';


class Recharge extends StatefulWidget {
  const Recharge({super.key});

  @override
  State<Recharge> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body: Container(
  // androidsmall4ZAH (1:5377)
  width:  double.infinity,
  height:  702*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroupkaghdvq (NYSpKwqdwJdw2SMFDfKagh)
  left:  0*fem,
  top:  0*fem,
  child:  
Container(
  width:  350*fem,
  height:  87*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        "",
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Center(
  child:  
Text(
  'Recharger une carte prépayée',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
Positioned(
  // menubuttonD8M (1:5379)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
  "",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
Positioned(
  // rechargeruneautrecarteTYV (1:5390)
  left:  20*fem,
  top:  222*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  176*fem,
  height:  17*fem,
  child:  
Text(
  'Recharger une autre Carte',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // carterecharger9AR (1:5391)
  left:  20*fem,
  top:  257*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  117*fem,
  height:  17*fem,
  child:  
Text(
  'Carte à recharger',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xb5066c0e),
  ),
),
),
),
),
Positioned(
  // autogroupxcbbeN5 (NYSpwm9HxdBU9xpYBdXCbb)
  left:  0*fem,
  top:  274*fem,
  child:  
Container(
  width:  350*fem,
  height:  428*fem,
  child:  
Stack(
  children:  [
Positioned(
  // line1xdf (1:5392)
  left:  20*fem,
  top:  12*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  117*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x6d000000),
  ),
),
),
),
),
Positioned(
  // autogroup36uwUc1 (NYSpTMnxC9PgqBUnP636uw)
  left:  17*fem,
  top:  28*fem,
  child:  
Container(
  width:  158*fem,
  height:  17*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // carterechargeraQ9 (1:5393)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 33.26*fem, 0*fem),
  child:  
TextButton(
  onPressed: () {
     Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Add your onTap functionality here
    // This function will be executed when the button is tapped
    // For example, you can navigate to a new screen or perform some action
  },
  child: Text(
    'Carte à recharger',
    style: TextStyle(
      fontFamily: 'Inter',
      fontSize: 14 * fem,
      fontWeight: FontWeight.w400,
      height: 1.2125 * fem / fem,
      color: Color(0xff0b11a4),
    ),
  ),
)
),
Container(
  // pathHZT (1:5406)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.95*fem),
  width:  7.74*fem,
  height:  9.05*fem,
  child:  
Image.network(
  'https://cdn4.iconfinder.com/data/icons/ionicons/512/icon-arrow-down-b-256.png',
  width:  7.74*fem,
  height:  9.05*fem,
),
),
  ],
),
),
),
Positioned(
  // line2zyf (1:5394)
  left:  17*fem,
  top:  55*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  213*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x99000000),
  ),
),
),
),
),
Positioned(
  // line4v6d (1:5395)
  left:  36*fem,
  top:  225.0229492188*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  213*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x70000000),
  ),
),
),
),
),
Positioned(
  // line5Rp5 (1:5396)
  left:  27*fem,
  top:  294*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  213*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x70000000),
  ),
),
),
),
),
Positioned(
  // line3KeZ (1:5397)
  left:  22*fem,
  top:  106*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  213*fem,
  height:  1*fem,
  child:  
Container(
  decoration:  BoxDecoration (
    color:  Color(0x99000000),
  ),
),
),
),
),
Positioned(
  // ajoutercarter8h (1:5398)
  left:  20*fem,
  top:  73*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  93*fem,
  height:  17*fem,
  child:  
Text(
  'Ajouter Carte:',
  style:   TextStyle (
    fontFamily:'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff1c06a8),
  ),
),
),
),
),
Positioned(
  // cartecomptedbiterYGR (1:5399)
  left:  20*fem,
  top:  159*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  162*fem,
  height:  17*fem,
  child:  
Text(
  'Carte/ Compte à débiter',
  style:  TextStyle (
    fontFamily:'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffe20e0e),
  ),
),
),
),
),
Positioned(
  // autogroupcdzzEQ9 (NYSpagv5AXXm3WfVcyCDzZ)
  left:  27*fem,
  top:  198*fem,
  child:  
Container(
  width:  165.81*fem,
  height:  17*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // mescomptesktH (1:5400)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 68.07*fem, 0*fem),
  child:  
Text(
  'Mes comptes',
  style:   TextStyle (
    fontFamily:'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff1d06a8),
  ),
),
),
Container(
  // pathG5w (1:5407)
  margin:  EdgeInsets.fromLTRB(0*fem, 2.05*fem, 0*fem, 0*fem),
  width:  7.74*fem,
  height:  9.05*fem,
  child:  
Image.network(
  "",
  width:  7.74*fem,
  height:  9.05*fem,
),
),
  ],
),
),
),
Positioned(
  // autogroupsz2qPRT (NYSphSDq9hN46xERQ3SZ2q)
  left:  27*fem,
  top:  269*fem,
  child:  
Container(
  width:  162.71*fem,
  height:  17*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // mescartesiCq (1:5401)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 80.97*fem, 0*fem),
  child:  
Text(
  'Mes cartes',
  style:  TextStyle (
    fontFamily:'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff1d06a8),
  ),
),
),
Container(
  // pathdah (1:5408)
  margin:  EdgeInsets.fromLTRB(0*fem, 2.05*fem, 0*fem, 0*fem),
  width:  7.74*fem,
  height:  9.05*fem,
  child:  
Image.network(
  "",
  width:  7.74*fem,
  height:  9.05*fem,
),
),
  ],
),
),
),
Positioned(
  // montantxcy (1:5402)
  left:  27*fem,
  top:  321*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  60*fem,
  height:  17*fem,
  child:  
Text(
  'Montant:',
  style:  TextStyle (
    fontFamily:'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff1d06a8),
  ),
),
),
),
),
Positioned(
  // oredrpickedupbuttonT3w (1:5403)
  left:  107*fem,
  top:  338*fem,
  child:  
Container(
  width:  101*fem,
  height:  21*fem,
  decoration:  BoxDecoration (
    color:  Color(0x284f4e5a),
    borderRadius:  BorderRadius.circular(15*fem),
  ),
  child:  
Center(
  child:  
Text(
  '0',
  style:  TextStyle (
    fontFamily:'Public Sans',
    fontSize:  15*fem,
    fontWeight:  FontWeight.w500,
    height:  1.175*fem/fem,
    letterSpacing:  0.4300000072*fem,
    color:  Color(0xff7367f0),
  ),
),
),
),
),
Positioned(
  // button17uB (1:5404)
  left:  75*fem,
  top:  374.5*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(50*fem, 0*fem, 53*fem, 0*fem),
  width:  174*fem,
  height:  26.5*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff1827b1)],
      stops:  <double>[0.151],
    ),
  ),
  child:  
Text(
  'Valider',
  style:  TextStyle (
    fontFamily:'Montserrat',
    fontSize:  20*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
),
  ],
),
),
),
  ],
),
      ));
}