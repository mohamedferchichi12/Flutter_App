import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';
import 'package:firebase_auth/firebase_auth.dart';

class Opposition extends StatefulWidget {
  const Opposition({super.key});

  @override
  State<Opposition> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body: 
Container(
  // androidsmall7mbw (1:8150)
  padding:  EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
  width:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupv5ezdu3 (NYSzsJwcqWLY2ki1KTV5eZ)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 66*fem),
  padding:  EdgeInsets.fromLTRB(66*fem, 14*fem, 51*fem, 1*fem),
  width:  double.infinity,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(20*fem),
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        "",
      ),
    ),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // oppositiongsK (1:8152)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 14*fem),
  child:  
Text(
  'Opposition',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  18*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
Container(
  // appelezimmdiatementlecentredop (1:8153)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
  constraints:  BoxConstraints (
    maxWidth:  224*fem,
  ),
  child:  
Text(
  'Appelez immédiatement le centre\n d’opposition ouvert 24h/24 et 7j/7',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
Container(
  // informationsfournirpc9 (1:8154)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
  child:  
Text(
  'Informations à fournir',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  18*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
  ],
),
),
Container(
  // numrodevotrecarteetsadatedexpi (1:8155)
  margin:  EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 0*fem),
  child:  
Text(
  'Numéro de votre carte et sa date dexpiration.',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // autogrouprd8vdZb (NYT1JoD9fvbRb5xqoxRD8V)
  padding:  EdgeInsets.fromLTRB(11*fem, 51*fem, 12*fem, 62*fem),
  width:  double.infinity,
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupvp9tZi9 (NYT12ZBDLSdJtadinrVP9T)
  margin:  EdgeInsets.fromLTRB(30*fem, 0*fem, 0*fem, 35*fem),
  height:  17*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupj7lmsiq (NYT19PKAc55HYS9UVUJ7LM)
  margin:  EdgeInsets.fromLTRB(0*fem, 12*fem, 10*fem, 4*fem),
  width:  121*fem,
  height:  double.infinity,
),
Container(
  // ouBjX (1:8158)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
  child:  
Text(
  'Ou',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // line2VkD (1:8157)
  margin:  EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 0*fem),
  width:  121*fem,
  height:  1*fem,
  decoration:  BoxDecoration (
    color:  Color(0xff000000),
  ),
),
  ],
),
),
Container(
  // adfautvosnomsprnomsadressedate (1:8160)
  margin:  EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 27*fem),
  constraints:  BoxConstraints (
    maxWidth:  267*fem,
  ),
  child:  
Text(
  'A défaut : vos noms, prénoms, adresse,date de\n naissance, agence, numéro de compte.',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // encasdevolfaitesunedclarationa (1:8161)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
  constraints:  BoxConstraints (
    maxWidth:  318*fem,
  ),
  child:  
Text(
  'En cas de vol, faites une déclaration au commissariat de\npolice et/ou aux autorités consulaires à l’étranger.',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // button18Au (1:8162)
  margin:  EdgeInsets.fromLTRB(11*fem, 0*fem, 10*fem, 40*fem),
  width:  double.infinity,
  height:  37*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff212d9b)],
      stops:  <double>[0.151],
    ),
  ),
  child:  
Center(
  child:  
Text(
  'Appeler centre d’opposition',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
Container(
  // telephoneZX7 (1:8164)
  margin:  EdgeInsets.fromLTRB(55*fem, 0*fem, 225*fem, 0*fem),
  padding:  EdgeInsets.fromLTRB(38*fem, 0*fem, 0*fem, 0*fem),
  width:  double.infinity,
  height:  21*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // telephonet3b (1:8166)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 0*fem),
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
Text(
  // zsK (1:8167)
  '71 155 840',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  18*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff000000),
  ),
),
  ],
),
),
  ],
),
),
  ],
)
  ));}