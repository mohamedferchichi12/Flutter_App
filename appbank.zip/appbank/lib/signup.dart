import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool _obscureText = true;

  final _emailController = TextEditingController();
  final _passWordController = TextEditingController();
  final _ConfirmpassWordController = TextEditingController();

  Future SignUp() async {
    if (_passWordController.text.trim() ==
            _ConfirmpassWordController.text.trim() &&
        _passWordController.text.trim().length >= 8) {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passWordController.text.trim(),
      );
      Navigator.of(context).pushNamed('/');
    }
  }

  goToSignUp() {
    Navigator.of(context).pushReplacementNamed('loginScreen');
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passWordController.dispose();
    _ConfirmpassWordController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff181f29),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Image
                Image.asset(
                  'assets/images/slogan.png',
                  //change image size*
                  width: 250,
                  height: 150,
                ),
               
                SizedBox(
                  height: 15,
                ),

                // Subtitle
                Text(
                  'Welcome to Solares ! you Can Register here  ',
                  style: GoogleFonts.robotoCondensed(
                    fontSize: 18,
                    color: Color.fromARGB(255, 245, 239, 237),
                  ),
                ),
                //make some distance between them
                SizedBox(
                  height: 25,
                ),
                // Email Textfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color(0xFFDCDCDC),
                        borderRadius: BorderRadius.circular(12)),
                    child: TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        hintText: 'Email'
                        //text position
                        ,
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                // Passwor Textfield
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color(0xFFDCDCDC),
                        borderRadius: BorderRadius.circular(12)),
                    child: TextField(
                      obscureText: _obscureText,
                      controller: _passWordController,
                      decoration: InputDecoration(
                        hintText: 'Password',
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        border: InputBorder.none,
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureText
                                ? Icons.visibility
                                : Icons.visibility_off,
                          ),
                          onPressed: () {
                            setState(() {
                              _obscureText = !_obscureText;
                            });
                          },
                        ),
                        // contentPadding: EdgeInsets.symmetric(horizontal: 20),
                        // border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25),
                  child: Container(
                    decoration: BoxDecoration(
                        color: Color(0xFFDCDCDC),
                        borderRadius: BorderRadius.circular(12)),
                    child: TextField(
                      controller: _ConfirmpassWordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        hintText: 'Confirm Password'
                        //text position
                        ,
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                // sign up  button
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25),
                  child: GestureDetector(
                    // onTap: SignIn,
                    child: Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Color(0xFF181F29),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Container(
                          width: 350,
                          height: 60,
                          child: Center(
                            child: ElevatedButton(
                              onPressed: SignUp,
                              style: ElevatedButton.styleFrom(
                                minimumSize: Size(350, 80),
                                primary: Color(0xFF42C95E), // Change the button color here
                              ),
                              child: Text(
                                'Sign Up',
                                style: GoogleFonts.robotoCondensed(
                                  fontSize: 20,
                                  color: Color(0xFFFFFFFF),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        )),
                  ),
                ),
                // Text: sign up
                SizedBox(
                  height: 30,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Alredy have Acount ?',
                      style: GoogleFonts.robotoCondensed(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(5),
                    ),
                    GestureDetector(
                      onTap: goToSignUp,
                      child: Text(
                        'Sign In now',
                        style: GoogleFonts.robotoCondensed(
                          fontWeight: FontWeight.bold,
                          color: Color(0xff42c95e),
                        ),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}