import 'package:appbank/opposition.dart';
import 'package:appbank/parametres.dart';
import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'cartes.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'loginscreen.dart';

class comptes extends StatefulWidget {
  const comptes({super.key});

  @override
  State<comptes> createState() => createState();
}
@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body: 
Container(
  // frame1hbw (1:8105)
  width:  double.infinity,
  height:  512*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Stack(
  children:  [
Positioned(
  // autogroup4w7jntH (VYjUpDcnV7KZfLg3Wj4W7j)
  left:  0*fem,
  top:  0*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(14*fem, 37*fem, 8*fem, 22*fem),
  width:  261*fem,
  height:  118*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        "",
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Center(
  // mescompteschoisissezlecomptepo (1:8117)
  child:  
SizedBox(
  child:  
Container(
  constraints:  BoxConstraints (
    maxWidth:  239*fem,
  ),
  child:  
Text(
  '                       Mes comptes:\n\nChoisissez le compte pour consulter votre\nsolde',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
),
),
),
Positioned(
  // menubuttonTsw (1:8107)
  left:  14*fem,
  top:  8*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  34*fem,
  height:  29*fem,
  child:  
Image.network(
  "https://cdn4.iconfinder.com/data/icons/wirecons-free-vector-icons/32/menu-alt-256.png",
  width:  34*fem,
  height:  29*fem,
),
),
),
),
Positioned(
  // autogroupji4hMiR (VYjX5KX19Pg3ZAYabAJi4h)
  left:  0*fem,
  top:  37*fem,
  child:  
Container(
  width:  261*fem,
  height:  475*fem,
  child:  
Stack(
  children:  [
Positioned(
  // autogrouppuswHMB (VYjWkAQFsrB36D8YG1pusw)
  left:  8*fem,
  top:  406*fem,
  child:  
Container(
  width:  141*fem,
  height:  51*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // vectoroqK (1:8118)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
  width:  40*fem,
  height:  28*fem,
  child:  
Image.network(
  "https://cdn0.iconfinder.com/data/icons/google-material-design-3-0/48/ic_supervisor_account_48px-256.png",
  width:  40*fem,
  height:  28*fem,
),
),
Container(
  // autogroupqekjY2D (VYjWraPEjBYbmzvALuqeKj)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22*fem),
  padding:  EdgeInsets.fromLTRB(14*fem, 0*fem, 14*fem, 0*fem),
  height:  29*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
    "",    
    ),
    ),
  ),
  child:  
Align(
  // vectorpVX (1:8120)
  alignment:  Alignment.topCenter,
  child:  
SizedBox(
  width:  26*fem,
  height:  23*fem,
  child:  
Image.network(
  "https://cdn3.iconfinder.com/data/icons/streamline-icon-set-free-pack/48/Streamline-18-256.png",
  width:  26*fem,
  height:  23*fem,
),
),
),
),
  ],
),
),
),
Positioned(
  // cashcoinZT7 (1:8121)
  left:  216*fem,
  top:  424*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  37*fem,
  height:  37*fem,
  child:  
Image.network(
  "https://cdn2.iconfinder.com/data/icons/aami-web-internet/64/aami7-76-256.png",
  width:  37*fem,
  height:  37*fem,
),
),
),
),
Positioned(
  // autogroupmbkmsih (VYjWvjvxv8JjSeBUW7mbkm)
  left:  3.5*fem,
  top:  457*fem,
  child:  
Container(
  width:  249.5*fem,
  height:  16*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // mescomptesQCq (1:8123)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 104.5*fem, 0*fem),
  child:  
Text(
  'Mes comptes\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x5e000000),
  ),
),
),
Text(
  // depensesu9b (1:8124)
  'Depenses',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  13*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0x49000000),
  ),
),
  ],
),
),
),
Positioned(
  // autogroup6pxdSQR (VYjUzDL8YB9Urt7CJ26PxD)
  left:  13*fem,
  top:  109*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(19*fem, 7*fem, 24*fem, 6*fem),
  width:  234*fem,
  height:  75*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffd9d9d9),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // comptetechnologiqueKUD (1:8128)
  width:  double.infinity,
  child:  
Text(
  'Compte Technologique\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // mohamedferchichiFcm (1:8131)
  width:  double.infinity,
  child:  
Text(
  'Mohamed Ferchichi',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // autogroupad5szKT (VYjVGYCGA7jH9oP9Efad5s)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // xxx207788Jb3 (1:8134)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 64*fem, 4*fem),
  child:  
Text(
  '1001XXX207788',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // tnd2X3 (1:8137)
  margin:  EdgeInsets.fromLTRB(0*fem, 4*fem, 0*fem, 0*fem),
  child:  
Text(
  '6.310 TND',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff1abd34),
  ),
),
),
  ],
),
),
Container(
  // autogroupwkrpMZK (VYjVPTAQiCnwQ4qirpwkRP)
  margin:  EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 0*fem),
  width:  67*fem,
  height:  15*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffa39696),
  ),
  child:  
Center(
  child:  
Text(
  'extrait',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
),
  ],
),
),
),
Positioned(
  // autogroup82thrFB (VYjVaN1ttKPN89fxo782th)
  left:  13*fem,
  top:  206*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(18*fem, 10*fem, 11*fem, 5*fem),
  width:  234*fem,
  height:  75*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffd9d9d9),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // comptechequepersonnelstbjJy (1:8129)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
  width:  double.infinity,
  child:  
Text(
  'Compte  Cheque personnel Stb\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // autogroup179tegq (VYjVnGqiTwMyyBr7ov179T)
  margin:  EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // autogroupssxrbMB (VYjVsmgZCDy38SEejpsSxR)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 6*fem),
  width:  93*fem,
  height:  23*fem,
  child:  
Stack(
  children:  [
Positioned(
  // mohamedferchichiiRo (1:8132)
  left:  0*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  93*fem,
  height:  13*fem,
  child:  
Text(
  'Mohamed Ferchichi',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // xxx207788cXB (1:8135)
  left:  1*fem,
  top:  10*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  77*fem,
  height:  13*fem,
  child:  
Text(
  '1001XXX207788',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
  ],
),
),
Text(
  // tnd59s (1:8138)
  '-7 720.501 TND',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffbd1111),
  ),
),
  ],
),
),
Container(
  // autogroupjnmp1pD (VYjVyGXPvWa6HgdBfjjnmP)
  margin:  EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
  padding:  EdgeInsets.fromLTRB(7*fem, 0*fem, 7*fem, 0*fem),
  width:  67*fem,
  height:  15*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffa39696),
  ),
  child:  
Text(
  'extrait\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
  ],
),
),
),
Positioned(
  // autogroupzglyVUV (VYjW9gPiPsURTHnU4kZgLy)
  left:  13*fem,
  top:  309*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(17*fem, 2*fem, 21*fem, 10*fem),
  width:  234*fem,
  height:  75*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffd9d9d9),
    borderRadius:  BorderRadius.circular(10*fem),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // comptepargneQ5f (1:8130)
  width:  double.infinity,
  child:  
Text(
  'Compte épargne\n',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
SizedBox(
  height:  5*fem,
),
Container(
  // autogroupulwkWPb (VYjWNLhHXczBe3U4PTULwK)
  margin:  EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
  width:  double.infinity,
  height:  25*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // autogroupbsgmeVo (VYjWUvLewsb7Wf9LKSbsgM)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 29*fem, 0*fem),
  width:  93*fem,
  height:  double.infinity,
  child:  
Stack(
  children:  [
Positioned(
  // mohamedferchichiz3s (1:8133)
  left:  0*fem,
  top:  0*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  93*fem,
  height:  13*fem,
  child:  
Text(
  'Mohamed Ferchichi',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
Positioned(
  // xxx207788J4Z (1:8136)
  left:  1*fem,
  top:  12*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  77*fem,
  height:  13*fem,
  child:  
Text(
  '1001XXX207788',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
),
),
  ],
),
),
Container(
  // tndc5F (1:8139)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
  child:  
Text(
  '8 526.633 TND',
  textAlign:  TextAlign.center,
  style:  TextStyle(
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff21c427),
  ),
),
),
  ],
),
),
SizedBox(
  height:  5*fem,
),
Container(
  // autogroupuplhtYZ (VYjWaLMJPhaV5Vb3KoupLh)
  margin:  EdgeInsets.fromLTRB(7*fem, 0*fem, 0*fem, 0*fem),
  padding:  EdgeInsets.fromLTRB(11*fem, 0*fem, 11*fem, 0*fem),
  width:  67*fem,
  height:  15*fem,
  decoration:  BoxDecoration (
    color:  Color(0xffa39696),
  ),
  child:  
Text(
  'extrait',
  textAlign:  TextAlign.center,
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  10*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
  ],
),
),
),
  ],
),
),
),
  ],
)));}