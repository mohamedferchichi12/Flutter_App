import 'package:appbank/recharge.dart';
import 'package:appbank/reclamation.dart';
import 'package:flutter/material.dart';
import 'package:appbank/parametres.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import 'cartes.dart';
import 'comptes.dart';
import 'loginscreen.dart';
import 'opposition.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => createState();
}

@override
Widget build(BuildContext context) {
  final double fem = 1.0;
  return Scaffold(
    appBar: AppBar(
        title: const Text('STB'),
        backgroundColor: Color(0xb2dea35f),
     
      ),
      drawer: Drawer(
        // Content of the drawer
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              Container(
                height: 200,
                child: UserAccountsDrawerHeader(
                  accountName: null,
                  accountEmail: null,
                  currentAccountPicture: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1,
                          color: Colors.white,
                        ),
                      ),
                      child: CircleAvatar(
                        // backgroundImage: from assets not network
                        backgroundImage: AssetImage('assets/Logo_STB.png'),

                        radius:
                            50, // Set the desired radius to enlarge the circular image
                      ),
                    ),
                  ),
                  decoration: BoxDecoration(
                    color: Color(0xb2dea35f),
                  ),
                ),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes cartes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => cartes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Recharge',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Recharge()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Mes comptes',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => comptes()),
                  )); // Action to be performed for option 1
                },
                leading: Icon(Icons.home),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Opposition',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                    builder: ((context) => Opposition()),
                  )); // Action to be performed for option 2
                },
                leading: Icon(Icons.category),
              ),
               SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Réclamation',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          reclamation()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Paramètres',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: ((context) =>
                          parametres()))); // Action to be performed for option 3
                },
                leading: Icon(Icons.settings),
              ),
              SizedBox(height: 20),
              ListTile(
                title: const Text(
                  'Déconnexion',
                  style: TextStyle(
                    fontSize: 18,
                    color: Color(0xb2dea35f),
                  ),
                ),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => loginScreen()),
                  );
                },
                leading: Icon(Icons.logout),
              ),
            ],
          ),
        ),
      ),
      body:
Container(
  // androidsmall5Acw (1:7932)
  width:  double.infinity,
  decoration:  BoxDecoration (
    color:  Color(0xffffffff),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // autogroup9egx3Aw (PbuHwPGGRJFRxZGpyR9EGX)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 83*fem),
  padding:  EdgeInsets.fromLTRB(15*fem, 7*fem, 26*fem, 2*fem),
  width:  302*fem,
  decoration:  BoxDecoration (
    image:  DecorationImage (
      fit:  BoxFit.cover,
      image:  NetworkImage (
        ""
      ),
    ),
    borderRadius:  BorderRadius.only (
      topLeft:  Radius.circular(20*fem),
      topRight:  Radius.circular(20*fem),
      bottomRight:  Radius.circular(40*fem),
      bottomLeft:  Radius.circular(40*fem),
    ),
  ),
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // autogroupuwawsfm (PbuJ6JB5nQ5USjREkduwAw)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
  width:  double.infinity,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // menubuttonc7Z (1:8015)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 48.63*fem, 0*fem),
  width:  23.38*fem,
  height:  15*fem,
  child:  
Image.network(
  '',
  width:  23.38*fem,
  height:  15*fem,
),
),
Text(
  // modifiezvotremotdepasseiAb (1:7978)
  'Modifiez votre mot de passe',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  14*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
  ],
),
),
Container(
  // saisissezvotrenouveaumotdepass (1:7936)
  margin:  EdgeInsets.fromLTRB(54*fem, 0*fem, 0*fem, 0*fem),
  constraints:  BoxConstraints (
    maxWidth:  137*fem,
  ),
  child:  
Text(
  'Saisissez votre nouveau\n\n       mot de passe :',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xffffffff),
  ),
),
),
  ],
),
),
Container(
  // modifiermonmotdepassei47 (1:7937)
  margin:  EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
  child:  
Text(
  'Modifier mon mot de passe',
  style:  TextStyle (
    fontFamily: 'Inter',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w400,
    height:  1.2125*fem/fem,
    color:  Color(0xff000000),
  ),
),
),
Container(
  // autogroupouvp1ou (PbuJmwhgrpvQsFNYBdouvP)
  width:  double.infinity,
  height:  340*fem,
  child:  
Stack(
  children:  [
Positioned(
  // button1kFh (1:7938)
  left:  16*fem,
  top:  4*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(10*fem, 2*fem, 10*fem, 4*fem),
  width:  199*fem,
  height:  22*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xffcbcbcb)],
      stops:  <double>[0.331],
    ),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // ancienmotdepasseyu9 (1:7939)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 35*fem, 0*fem),
  child:  
Text(
  'Ancien mot de passe',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
Container(
  // eyegoZ (1:7940)
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  '',
  width:  16*fem,
  height:  16*fem,
),
),
  ],
),
),
),
Positioned(
  // button226j (1:7945)
  left:  13*fem,
  top:  39*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(4*fem, 2*fem, 4*fem, 4*fem),
  width:  212*fem,
  height:  22*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xffcbcbcb)],
      stops:  <double>[0.331],
    ),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // lockGWs (1:7946)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  '',
  width:  16*fem,
  height:  16*fem,
),
),
Container(
  // nouveaumotdepasseAMM (1:7956)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 0*fem),
  child:  
Text(
  'Nouveau mot de passe',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
Container(
  // eyefou (1:7957)
  width:  16*fem,
  height:  16*fem,
  child:  
Image.network(
  "",
  width:  16*fem,
  height:  16*fem,
),
),
  ],
),
),
),
Positioned(
  // button4ov7 (1:7962)
  left:  5*fem,
  top:  261*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(81*fem, 0*fem, 82.5*fem, 0*fem),
  width:  270*fem,
  height:  29*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xff3e4bbd)],
      stops:  <double>[0.331],
    ),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // valider68X (1:7963)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 15.5*fem, 2*fem),
  child:  
Text(
  'Valider',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  22*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
Container(
  // lock2H5 (1:7964)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
  width:  13*fem,
  height:  16*fem,
  child:  
Image.network(
  '',
  width:  13*fem,
  height:  16*fem,
),
),
  ],
),
),
),
Positioned(
  // button3LoZ (1:7965)
  left:  16*fem,
  top:  221*fem,
  child:  
Container(
  padding:  EdgeInsets.fromLTRB(3*fem, 1*fem, 0*fem, 1*fem),
  width:  247.5*fem,
  height:  20*fem,
  decoration:  BoxDecoration (
    borderRadius:  BorderRadius.circular(30*fem),
    gradient:  LinearGradient (
      begin:  Alignment(-1, 0),
      end:  Alignment(1, 0),
      colors:  <Color>[Color(0xffcbcbcb)],
      stops:  <double>[0.331],
    ),
  ),
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.center,
  children:  [
Container(
  // lockoSF (1:7966)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 11.5*fem, 2*fem),
  width:  13*fem,
  height:  16*fem,
  child:  
Image.network(
  '',
  width:  13*fem,
  height:  16*fem,
),
),
Container(
  // confirmervotremotdepasse8Dd (1:7967)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 2*fem),
  child:  
Text(
  'Confirmer votre mot de passe',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xfffdf5f5),
  ),
),
),
Container(
  // eye3Lb (1:8010)
  width:  18*fem,
  height:  13*fem,
  child:  
Image.network(
  '',
  width:  18*fem,
  height:  13*fem,
),
),
  ],
),
),
),
Positioned(
  // check2mnP (1:7969)
  left:  22*fem,
  top:  82*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  27*fem,
  height:  27*fem,
  child:  
Image.network(
  '',
  width:  27*fem,
  height:  27*fem,
),
),
),
),
Positioned(
  // autogroupwxewguM (PbuJRcxDcror6WivvsWXew)
  left:  29.21875*fem,
  top:  161.90625*fem,
  child:  
Container(
  width:  127.78*fem,
  height:  15.09*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // check2Csh (1:7971)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 0.38*fem, 0*fem),
  width:  19.41*fem,
  height:  13.5*fem,
  child:  
Image.network(
  '',
  width:  19.41*fem,
  height:  13.5*fem,
),
),
Container(
  // aumoins1chiffreXQB (1:7977)
  margin:  EdgeInsets.fromLTRB(0*fem, 0.09*fem, 0*fem, 0*fem),
  child:  
Text(
  'Au moins 1 chiffre',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff766d6d),
  ),
),
),
  ],
),
),
),
Positioned(
  // autogrouphnxfRVZ (PbuJKd8DBpWhNnfSThHnxF)
  left:  28.21875*fem,
  top:  136.90625*fem,
  child:  
Container(
  width:  148.78*fem,
  height:  16.09*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // check2Yq5 (1:7972)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 1.38*fem, 0*fem),
  width:  19.41*fem,
  height:  13.5*fem,
  child:  
Image.network(
  "",
  width:  19.41*fem,
  height:  13.5*fem,
),
),
Container(
  // aumoins1minisculeGm5 (1:7976)
  margin:  EdgeInsets.fromLTRB(0*fem, 1.09*fem, 0*fem, 0*fem),
  child:  
Text(
  'Au moins 1 miniscule',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff766d6d),
  ),
),
),
  ],
),
),
),
Positioned(
  // autogrouph4wtbYT (PbuJDD9ELV98gzspNoH4WT)
  left:  27.21875*fem,
  top:  111.90625*fem,
  child:  
Container(
  width:  153.78*fem,
  height:  15.09*fem,
  child:  
Row(
  crossAxisAlignment:  CrossAxisAlignment.start,
  children:  [
Container(
  // check28YP (1:7973)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 2.38*fem, 0*fem),
  width:  19.41*fem,
  height:  13.5*fem,
  child:  
Image.network(
  "",
  width:  19.41*fem,
  height:  13.5*fem,
),
),
Container(
  // aumoins1majusculerDV (1:7975)
  margin:  EdgeInsets.fromLTRB(0*fem, 0.09*fem, 0*fem, 0*fem),
  child:  
Text(
  'Au moins 1 majuscule',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff766d6d),
  ),
),
),
  ],
),
),
),
Positioned(
  // aumoins8caractresZdh (1:7974)
  left:  49*fem,
  top:  88*fem,
  child:  
Align(
  child:  
SizedBox(
  width:  135*fem,
  height:  15*fem,
  child:  
Text(
  'Au moins 8 caractères',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0xff766c6c),
  ),
),
),
),
),
  ],
),
),
Container(
  // autogroupxg6je9M (PbuJY2wCUCBQnJWZ1mXG6j)
  width:  360*fem,
  height:  47*fem,
  child:  
Image.network(
  "",
  width:  360*fem,
  height:  47*fem,
),
),
Container(
  // autogroup4qxtyhR (PbuKDBUdqsLFeLntuW4qxT)
  padding:  EdgeInsets.fromLTRB(234*fem, 0*fem, 0*fem, 7*fem),
  width:  double.infinity,
  height:  22*fem,
  child:  
Column(
  crossAxisAlignment:  CrossAxisAlignment.end,
  children:  [
Container(
  // infocircleJUo (1:7982)
  width:  16*fem,
  height:  16*fem,
),
Container(
  // aproposfKM (1:7984)
  margin:  EdgeInsets.fromLTRB(0*fem, 0*fem, 12*fem, 0*fem),
  child:  
Text(
  'A propos',
  style:  TextStyle (
    fontFamily: 'Montserrat',
    fontSize:  12*fem,
    fontWeight:  FontWeight.w500,
    height:  1.2175*fem/fem,
    color:  Color(0x93000000),
  ),
),
),
  ],
),
),
 ],
),
));}